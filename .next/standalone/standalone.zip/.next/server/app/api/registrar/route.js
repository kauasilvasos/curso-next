var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/registrar/route.js")
R.c("server/chunks/[externals]__1b8b210d._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/[root-of-the-server]__479cebcf._.js")
R.c("server/chunks/_next-internal_server_app_api_registrar_route_actions_24c21a2f.js")
R.m(42648)
module.exports=R.m(42648).exports
