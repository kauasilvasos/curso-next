module.exports=[70218,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_registrar_route_actions_24c21a2f.js.map